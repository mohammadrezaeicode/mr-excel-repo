export declare function hexToRgbArray(hex: string): number[];
export declare function generateContrastTextColor(b: string): "rgb(0,0,0)" | "rgb(255,255,255)" | undefined;
export declare function hexToRgbNegative(hex: string): string;
export declare function rgbToHex(rgb: string): string | null;
export declare function convertToHex(fgConvertor: string | undefined, backend: boolean | undefined): string | null;
//# sourceMappingURL=color.d.ts.map