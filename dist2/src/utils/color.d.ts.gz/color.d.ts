export declare function rgbToHex(rgb: string): string | null;
export declare function convertToHex(fgConvertor: string | undefined, backend: boolean | undefined): string | null;
//# sourceMappingURL=color.d.ts.map