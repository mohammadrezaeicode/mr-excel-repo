import { MultiStyleValue } from "../data-model/excel-table";
export declare function generateMultiStyleValue(multiStyle: MultiStyleValue, text: string, styles: {
    [key: string]: string;
}, defStyleId: string): string;
//# sourceMappingURL=multi-value.d.ts.map