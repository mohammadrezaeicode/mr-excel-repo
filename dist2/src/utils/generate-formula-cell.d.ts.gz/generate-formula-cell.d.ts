import { FormulaSetting, Styles } from "../data-model/excel-table";
export declare function generateCellRowCol(string: string, formula: FormulaSetting, styles?: Styles): {
    column: string;
    row: number;
    cell: string;
};
//# sourceMappingURL=generate-formula-cell.d.ts.map